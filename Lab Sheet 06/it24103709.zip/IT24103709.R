
> setwd("/Users/indeevara/Desktop/IT24103709")
> ##Question 1
> #Part 1
> #Binomial Distribution
> #Here, random variable X has binomial distribution with n = 50 and p = 0.85
> 
> #Part 2
> pbinom(46, 50, 0.85, lower.tail = FALSE)
[1] 0.04604658
> 
> ##Question 2
> #Part 1
> #Number of calls in 1 hour
> 
> #Part 2
>  #Poisson distribution
> #Here, random variable X has poisson distribution with lambda=12
> 
> #Part 3
> dpois(15, 12)
[1] 0.07239112
> 